let body = document.body;

function handleClick(e) {
  console.log("Number of clicks");
}

body.addEventListener("click", handleClick);
